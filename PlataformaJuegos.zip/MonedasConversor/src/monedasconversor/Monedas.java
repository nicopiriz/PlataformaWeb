package monedasconversor;

import java.awt.BorderLayout;
import static java.awt.BorderLayout.CENTER;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import static java.awt.image.ImageObserver.HEIGHT;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class Monedas extends JFrame {
    /*
    ELEGI HACERLO SOLAMENTE CON CODIGO PARA IR ACOSTUMBRANDOME A LAS 
    SENTENCIAS. NO PUDE SOLUCIONAR DOS ERRORES:
    1°CUANDO INGRESO UN STRING QUE ME AVISE Y ME DE LA OPCION DE VOLVER A 
    INGRESAR OTRO DATO
    
    2°CUANDO INGRESO UN NUMERO DECIMAL NO SE PORQUE ME SALTA ERROR
    */
    

    JTextArea txtarea1 = new JTextArea(10, 44);
    JTextArea txtarea2 = new JTextArea(10, 44);
    JLabel desde = new JLabel("Desde");
    JLabel a = new JLabel("A");
    JComboBox combo1 = new JComboBox();
    JComboBox combo2 = new JComboBox();
    JButton convertir = new JButton("Convertir");
    JButton limpiar = new JButton("Limpiar");
    JPanel panel = new JPanel();
    Font fuente = new Font("Arial", Font.BOLD, 14);

    public void cargarCombobox() {
        combo1.addItem("Peso");
        combo1.addItem("Dolar");
        combo2.addItem("Dolar");
        combo2.addItem("Peso");
    }

    public void mostrarValorPesoDolar() {
        double a = Integer.parseInt(txtarea1.getText());
        double b = a * 0.04;
        String.valueOf(b);
        String.format("%.3f", b);
        txtarea2.setText(String.valueOf(b));
    }
    public void mostrarValorDolarPeso() {
        double a = Integer.parseInt(txtarea1.getText());
        double b = a * 28.03;
        String.valueOf(b);
        String.format("%.3f", b);
        txtarea2.setText(String.valueOf(b));
    }

    
    /*
    EN ESTE METODO PREFERI USAR VARIOS IF ANIDADOS PORQUE NO TENGO 
    MUCHA PRACTICA CON LA HERRAMIENTA CASE. PERDON SI QUEDO MUY DESPROLIJO
    */
    public void cargarListener() {
        convertir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (txtarea1.getText().length()==0){
                    JOptionPane.showMessageDialog(null, "Cuadro de texto vacio", "Error", HEIGHT);
                }
                else{
                try{
                    Integer.parseInt(txtarea1.getText());
                }catch(NumberFormatException nfe){
                    JOptionPane.showMessageDialog(null, "No es un valor numerico", "Error", HEIGHT);
                    txtarea1.setText(null);
                }
                
                if (combo1.getSelectedIndex() == 0) {//COMPRUEBO LAS SELECCIONES DEL COMBOBOX
                    if (combo2.getSelectedIndex() == 0) {
                        mostrarValorPesoDolar(); 
                    } else {
                        txtarea2.setText(txtarea1.getText());
                    }

                }
                if (combo1.getSelectedIndex() == 1) {
                    if (combo2.getSelectedIndex() == 1) {
                        mostrarValorDolarPeso();
                    } else {
                        txtarea2.setText(txtarea1.getText());
                    }
                }
            }
            }
        });

        limpiar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtarea1.setText(null);
                txtarea2.setText(null);
                txtarea1.requestFocus();
            }
        });
    }

    public void crearPanel() {;
        this.setLayout(new FlowLayout());
        this.setTitle("Conversor de monedas");
        this.getContentPane().setBackground(Color.lightGray);
        this.setSize(500, 450);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.add(txtarea1);
        this.add(desde);
        this.add(combo1);
        this.add(a);
        this.add(combo2);
        this.add(txtarea2);
        this.add(convertir);
        this.add(limpiar);

        txtarea1.setLineWrap(true);
        txtarea2.setLineWrap(true);
    }

    public void iniciar() {
        cargarCombobox();
        cargarListener();
        crearPanel();
        txtarea2.setEditable(false);
        this.setVisible(true);
        this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
    }
}
