
package monedasconversor;

public class MonedasConversor {

    public static void main(String[] args) {
        // TODO code application logic here
        
        
        Monedas moneda = new Monedas ();
        moneda.iniciar();
      
    }
    
}

