package vista;

import java.awt.*;
import java.nio.file.Files;
import javax.swing.*;

public class VistaLogin {

    public static void main(String[] args) {
        JFrame ventana = new JFrame();
        JPanel panelPrincipal = new JPanel();
        JPanel panelCentro = new JPanel();
        JPanel panelSur = new JPanel();
        JPanel panel1 = new JPanel();
        JLabel usuario = new JLabel("Usuario");
        JLabel contrasenia = new JLabel("Contraseña");
        JTextField txtusuario = new JTextField("", 20);
        JTextField txtcontrasenia = new JTextField("", 20);
        JButton ingresar = new JButton("Ingresar");
        JButton olvidar = new JButton("¿Olvido su contraseña?");


     
    //PANEL PARA LOS LABELS Y TEXTBOXS ACOMODADOS EN COLUMNAS
    GridBagLayout grid = new GridBagLayout();
    panel1.setLayout(grid);
    panel1.add(usuario);
    panel1.add(txtusuario);
    panel1.add(contrasenia);
    panel1.add(txtcontrasenia);


        


        //CREO LAYOUT PARA GUARDAR LOS BOTONES Y GUARDARLOS AL SUR DEL PANEL
        FlowLayout flow = new FlowLayout(FlowLayout.LEFT, 15, 0);
        panelSur.setLayout(flow);
        panelSur.add(ingresar);
        panelSur.add(olvidar);

        BorderLayout border = new BorderLayout();
        panelPrincipal.setLayout(border);


        panelPrincipal.add(panel1, BorderLayout.CENTER);
        panelPrincipal.add(panelSur, BorderLayout.SOUTH);

        ventana.add(panelPrincipal);
        ventana.setSize(340, 400);
        ventana.setLocationRelativeTo(null);
        ventana.setResizable(true);
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
