package vista;

import java.awt.*;
import java.nio.file.Files;
import javax.swing.*;

public class VistaLogin {

    public static void main(String[] args) {
        JFrame ventana = new JFrame();
        JPanel panelPrincipal = new JPanel();
        JPanel panelCentro = new JPanel();
        JPanel panelSur = new JPanel();
        JPanel panelIzquierdo = new JPanel();
        JPanel panelDerecho = new JPanel();
        JPanel panelNorte= new JPanel();
        JPanel panelBotones = new JPanel();
        JLabel usuario = new JLabel("Usuario");
        JLabel contrasenia = new JLabel("Contraseña");
        JTextField txtusuario = new JTextField(10);
        JTextField txtcontrasenia = new JTextField(10);
        JButton ingresar = new JButton("Ingresar");
        JButton olvidar = new JButton("¿Olvido su contraseña?");

        BorderLayout border = new BorderLayout();
        FlowLayout flow = new FlowLayout();
                
        //AGREGO LOS BOTONES AL PANELSUR
        panelSur.setLayout(flow);
        panelSur.add(ingresar,FlowLayout.LEFT);
        panelSur.add(olvidar);
        
        //AGREGO LOS JLABELS Y JTEXTFIELD AL CENTRO

        panelCentro.setLayout(border);
        //panelCentro.setSize(new Dimension(1, 1));
        panelCentro.add(usuario,BorderLayout.CENTER);
        panelCentro.add(txtusuario);
        panelCentro.add(contrasenia);
        panelCentro.add(txtcontrasenia);
        
    
        
        
        
        
        
        
        //AÑADIO TODOS LOS PANEL AL PANEL PRINCIPAL CON EL BORDERLAYOUT
        panelPrincipal.setLayout(border);
        panelPrincipal.add(panelNorte, BorderLayout.NORTH);
        panelPrincipal.add(panelSur, BorderLayout.SOUTH);
        panelPrincipal.add(panelIzquierdo, BorderLayout.WEST);
        panelPrincipal.add(panelDerecho, BorderLayout.EAST);
        panelPrincipal.add(panelCentro, BorderLayout.CENTER);
        
        


        ventana.add(panelPrincipal);
        ventana.setSize(300, 400);
        ventana.setLocationRelativeTo(null);
        ventana.setResizable(true);
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
