/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;
import plataformajuegos.BaseDeDatos;




public class Inicio extends javax.swing.JFrame {



    public Inicio() {
        initComponents();
        this.setLocationRelativeTo(null);
        llenarTabla();
    }

    
    public void llenarTabla(){
        DefaultTableModel modelo = new DefaultTableModel();
        String SQL = ("SELECT nombre,genero.genero,idioma.idioma,consola.consola,peso,fecha_lanzamiento,precio\n" +
"FROM plataformajuegos.juegos \n" +
"INNER JOIN plataformajuegos.consola ON juegos.idconsola= consola.idconsola\n" +
"INNER JOIN plataformajuegos.genero ON juegos.idgenero = genero.idgenero\n" +
"INNER JOIN plataformajuegos.idioma ON juegos.ididioma = idioma.ididioma");
        ResultSet rs = BaseDeDatos.getTabla(SQL);
        modelo.setColumnIdentifiers(new Object[]{"Nombre","Genero","Idioma","Consola","Peso","Fecha lanzamiento","Precio"} );
        
        try{
            while(rs.next()){
                modelo.addRow(new Object[]{rs.getString("nombre"),rs.getString("genero"),rs.getString("idioma"),
                rs.getString("consola"),rs.getString("peso"),rs.getString("fecha_lanzamiento"),rs.getString("precio")
                });
            }
            jTableJuegos.setModel(modelo);
        }catch(Exception e){
            System.out.println(e);
        }
        
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        TipoPago = new javax.swing.ButtonGroup();
        jPanelUsuario = new javax.swing.JPanel();
        jLabelNombreUsuario = new javax.swing.JLabel();
        jLabelCerrarSesion = new javax.swing.JLabel();
        jLabelIdUsuario = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableJuegos = new javax.swing.JTable();
        jPanelInformacion = new javax.swing.JPanel();
        jLabelJNCorp = new javax.swing.JLabel();
        jLabelCondicionesServicio = new javax.swing.JLabel();
        jLabelInformacion = new javax.swing.JLabel();
        jLabelIcono = new javax.swing.JLabel();
        Seleccionar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabelSubtotal = new javax.swing.JLabel();
        jTextFieldSubtotal = new javax.swing.JTextField();
        jButtonQuitar = new javax.swing.JButton();
        jRadioButtonContado = new javax.swing.JRadioButton();
        jRadioButtonCredito = new javax.swing.JRadioButton();
        jButton1 = new javax.swing.JButton();
        jLabelFondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanelUsuario.setOpaque(false);

        jLabelNombreUsuario.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabelNombreUsuario.setForeground(new java.awt.Color(255, 255, 255));
        jLabelNombreUsuario.setText("Usuario");

        jLabelCerrarSesion.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabelCerrarSesion.setForeground(new java.awt.Color(255, 255, 255));
        jLabelCerrarSesion.setText("Cerrar sesion");

        jLabelIdUsuario.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabelIdUsuario.setForeground(new java.awt.Color(255, 255, 255));
        jLabelIdUsuario.setText("ID:");

        javax.swing.GroupLayout jPanelUsuarioLayout = new javax.swing.GroupLayout(jPanelUsuario);
        jPanelUsuario.setLayout(jPanelUsuarioLayout);
        jPanelUsuarioLayout.setHorizontalGroup(
            jPanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelUsuarioLayout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addComponent(jLabelIdUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabelNombreUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(28, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelUsuarioLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabelCerrarSesion))
        );
        jPanelUsuarioLayout.setVerticalGroup(
            jPanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelUsuarioLayout.createSequentialGroup()
                .addGroup(jPanelUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelNombreUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelIdUsuario))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
                .addComponent(jLabelCerrarSesion))
        );

        getContentPane().add(jPanelUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 0, 330, 60));

        jScrollPane1.setOpaque(false);

        jTableJuegos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Nombre", "Genero", "Idioma", "Consola", "Peso", "Fecha lanzamiento", "Precio"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Float.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableJuegos.setOpaque(false);
        jScrollPane1.setViewportView(jTableJuegos);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 790, 130));

        jPanelInformacion.setOpaque(false);

        jLabelJNCorp.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabelJNCorp.setForeground(new java.awt.Color(255, 255, 255));
        jLabelJNCorp.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelJNCorp.setText("J & N Corp. 2018");

        jLabelCondicionesServicio.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabelCondicionesServicio.setForeground(new java.awt.Color(255, 255, 255));
        jLabelCondicionesServicio.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelCondicionesServicio.setText("Condiciones de Servicio");

        jLabelInformacion.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabelInformacion.setForeground(new java.awt.Color(255, 255, 255));
        jLabelInformacion.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelInformacion.setText("Informacion");

        javax.swing.GroupLayout jPanelInformacionLayout = new javax.swing.GroupLayout(jPanelInformacion);
        jPanelInformacion.setLayout(jPanelInformacionLayout);
        jPanelInformacionLayout.setHorizontalGroup(
            jPanelInformacionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelInformacionLayout.createSequentialGroup()
                .addGap(128, 128, 128)
                .addComponent(jLabelCondicionesServicio)
                .addGap(44, 44, 44)
                .addComponent(jLabelJNCorp, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addComponent(jLabelInformacion, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(317, Short.MAX_VALUE))
        );
        jPanelInformacionLayout.setVerticalGroup(
            jPanelInformacionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelInformacionLayout.createSequentialGroup()
                .addGroup(jPanelInformacionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelJNCorp, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelInformacion, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelCondicionesServicio, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, Short.MAX_VALUE))
        );

        getContentPane().add(jPanelInformacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 480, 900, 40));

        jLabelIcono.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelIcono.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoJN.png"))); // NOI18N
        getContentPane().add(jLabelIcono, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 10, -1, 120));

        Seleccionar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/353403-cart_107514.png"))); // NOI18N
        Seleccionar.setText("Añadir al carro");
        Seleccionar.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        getContentPane().add(Seleccionar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 170, 40));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null}
            },
            new String [] {
                "Nombre", "Precio"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Float.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(jTable1);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 790, 100));

        jLabelSubtotal.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabelSubtotal.setForeground(new java.awt.Color(255, 255, 255));
        jLabelSubtotal.setText("Subtotal :");
        getContentPane().add(jLabelSubtotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 420, 70, 30));

        jTextFieldSubtotal.setEditable(false);
        jTextFieldSubtotal.setBackground(new java.awt.Color(0, 51, 51));
        jTextFieldSubtotal.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jTextFieldSubtotal.setForeground(new java.awt.Color(255, 255, 255));
        jTextFieldSubtotal.setText("0.0");
        getContentPane().add(jTextFieldSubtotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 420, 130, 30));

        jButtonQuitar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/emblemunreadable_93487 (1).png"))); // NOI18N
        jButtonQuitar.setText("Quitar");
        jButtonQuitar.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButtonQuitar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonQuitarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonQuitar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 410, 170, 40));

        TipoPago.add(jRadioButtonContado);
        jRadioButtonContado.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jRadioButtonContado.setForeground(new java.awt.Color(255, 255, 255));
        jRadioButtonContado.setText("Contado");
        jRadioButtonContado.setOpaque(false);
        getContentPane().add(jRadioButtonContado, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 410, 130, -1));

        TipoPago.add(jRadioButtonCredito);
        jRadioButtonCredito.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jRadioButtonCredito.setForeground(new java.awt.Color(255, 255, 255));
        jRadioButtonCredito.setText("Tarjeta de credito");
        jRadioButtonCredito.setOpaque(false);
        getContentPane().add(jRadioButtonCredito, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 430, 140, -1));

        jButton1.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Desktop\\shopping-basket-e-commerce-symbol_icon-icons.com_73162 (1).png")); // NOI18N
        jButton1.setText("Efectuar compra");
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 410, 170, 40));

        jLabelFondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/FondoAzul.png"))); // NOI18N
        getContentPane().add(jLabelFondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -60, 920, 580));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonQuitarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonQuitarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButtonQuitarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Seleccionar;
    private javax.swing.ButtonGroup TipoPago;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButtonQuitar;
    private javax.swing.JLabel jLabelCerrarSesion;
    private javax.swing.JLabel jLabelCondicionesServicio;
    private javax.swing.JLabel jLabelFondo;
    private javax.swing.JLabel jLabelIcono;
    private javax.swing.JLabel jLabelIdUsuario;
    private javax.swing.JLabel jLabelInformacion;
    private javax.swing.JLabel jLabelJNCorp;
    private javax.swing.JLabel jLabelNombreUsuario;
    private javax.swing.JLabel jLabelSubtotal;
    private javax.swing.JPanel jPanelInformacion;
    private javax.swing.JPanel jPanelUsuario;
    private javax.swing.JRadioButton jRadioButtonContado;
    private javax.swing.JRadioButton jRadioButtonCredito;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTableJuegos;
    private javax.swing.JTextField jTextFieldSubtotal;
    // End of variables declaration//GEN-END:variables
    BaseDeDatos mysql = new BaseDeDatos();
    Connection cn = mysql.Connectar();

}
