/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import plataformajuegos.BaseDeDatos;

/**
 *
 * @author USUARIO
 */
public class NuevoUsuario extends javax.swing.JFrame {

    /**
     * Creates new form NuevoUsuario
     */
    public NuevoUsuario() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        jLabelRegistrarse.requestFocus();
        jLabelNombreError.setVisible(false);
        jLabelNombreOk.setVisible(false);
        jLabelApellidoError.setVisible(false);          // POR DEFECTO DESACTIVO
        jLabelApellidoOk.setVisible(false);            // LA VISTA DE LOS LABELS
        jLabelDniError.setVisible(false);              //DE ERROR Y OK
        jLabelDniOk.setVisible(false);
        jLabelLocalidadError.setVisible(false);
        jLabelLocalidadOk.setVisible(false);
        jLabelDireccionError.setVisible(false);
        jLabelDireccionOk.setVisible(false);
        jLabelMailError.setVisible(false);
        jLabelMailOk.setVisible(false);
        jLabelUserError.setVisible(false);
        jLabelUserOk.setVisible(false);
        jLabelContraError.setVisible(false);
        jLabelContraOk.setVisible(false);
        getanios();

        //POR DEFECTO DESACTIVO EL PANEL PARA AGREGAR TARJETA
        for (int i = 0; i < jPanel1.getComponents().length; i++) {
            jPanel1.getComponent(i).setEnabled(false);
            jLabelIconoTarjeta.setEnabled(true);
        }
        this.setTitle("Registrarse");
    }

    public void IngresarUsuarioYTarjeta() {
        try {
            if (verificaciones() == true && comprobarDatosTarjeta() == true) {

                //INGRESO PRIMERO EL DETALLE DE TARJETA
                String nombreTitular, vencimiento, numeroTarjeta, codigoSeguridad,
                        SQLNuevoDetalle;

                nombreTitular = jTextFieldTitularTarjeta.getText();
                String dia = "01";
                vencimiento = jTextFieldVencimientoTarjetaAnio.getText() + "-"
                        + jTextFieldVencimientoTarjetaMes.getText() + "-" + dia;
                numeroTarjeta = jTextFieldNumeroTarjeta.getText();
                codigoSeguridad = jTextFieldCodigoTarjeta.getText();

                SQLNuevoDetalle = ("INSERT INTO detalle_tarjeta (nombre_titular,"
                        + "vencimiento,numero,cod_seguridad)VALUES(?,?,?,?)");
                PreparedStatement P = cn.prepareStatement(SQLNuevoDetalle);
                P.setString(1, nombreTitular);
                P.setString(2, vencimiento);
                P.setString(3, numeroTarjeta);
                P.setString(4, codigoSeguridad);
                P.execute();
                P.close();

                //BUSCO EL ULTIMO REGISTRO DE LA TABLA DETALLE_TARJETA PARA GUARDAR EL ID
                String idDetalle_tarjeta = "";
                String SQLIdDetalle_Tarjeta
                        = ("SELECT * FROM  detalle_tarjeta ORDER BY iddetalle_tarjeta DESC");

                Statement st = cn.createStatement(); //CREO EL OBJETO STATEMENT
                ResultSet rs = st.executeQuery(SQLIdDetalle_Tarjeta); //EJECUTO LA CONSULTA SQL
                if (rs.next()) {

                    idDetalle_tarjeta = rs.getString("iddetalle_tarjeta");
                }

                //INGRESO EL NUEVO USUARIO Y CON EL ID DE DETALLE_TARJETA LO VINCULO
                String nombre, apellido, dni, localidad, direccion, fechaNacimiento,
                        email, nombreUsuario, contraseña, sql;
                nombre = jTextFieldNombre.getText();
                apellido = jTextFieldApellido.getText();
                dni = jTextFieldDni.getText();
                localidad = jTextFieldLocalidad.getText();
                direccion = jTextFieldDireccion.getText();
                fechaNacimiento = jComboBoxAnios.getSelectedItem().toString() + "-"
                        + jComboBoxMeses.getSelectedItem().toString() + "-"
                        + jComboBoxDias.getSelectedItem().toString();
                email = jTextFieldMail.getText();
                nombreUsuario = jTextFieldNickName.getText();
                contraseña = new String(jPasswordFieldContrasenia.getPassword());
                int idDetalleTarjeta = Integer.parseInt(idDetalle_tarjeta);

                sql = ("INSERT INTO cliente(nombre,apellido,dni,localidad,direccion,"
                        + "fecha_nacimiento,mail,iddetalle_tarjeta)"+"VALUES(?,?,?,?,?,?,?,?)");
                PreparedStatement pst = cn.prepareStatement(sql);
                pst.setString(1, nombre);
                pst.setString(2, apellido);
                pst.setString(3, dni);
                pst.setString(4, localidad);
                pst.setString(5, direccion);
                pst.setString(6, fechaNacimiento);
                pst.setString(7, email);
                pst.setInt(8, idDetalleTarjeta);
                pst.execute();
                pst.close();

                //BUSCO EL ULTIMO REGISTRO DE LA TABLA CLIENTE PARA GUARDAR EL ID
                String idUltimoCliente = "";
                String SQLIdCliente = ("SELECT * FROM  cliente ORDER BY idcliente DESC");

                Statement st2 = cn.createStatement(); //CREO EL OBJETO STATEMENT
                ResultSet rs2 = st2.executeQuery(SQLIdCliente); //EJECUTO LA CONSULTA SQL
                if (rs2.next()) {

                    idUltimoCliente = rs2.getString("idCliente");
                }

                //INGRESO EL USUARIO Y CONTRASEÑA EN LA TABLA USUARIO
                int id_cliente = Integer.parseInt(idUltimoCliente);
                String SQLCuenta = 
                        ("INSERT INTO usuario (nickname,contrasenia,idcliente)VALUES(?,?,?)");
                PreparedStatement PUser = cn.prepareStatement(SQLCuenta);
                PUser.setString(1, nombreUsuario);
                PUser.setString(2, contraseña);
                PUser.setInt(3, id_cliente);
                PUser.execute();
                PUser.close();

                JOptionPane.showMessageDialog(null, "Datos registrados");
                this.dispose();
                Login vps = new Login();
                vps.setVisible(true);

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error");
        }

    }

    public void IngresarUsuarioSinTarjeta() throws SQLException {
        String nombre, apellido, dni, localidad, direccion, fechaNacimiento,
                email, nombreUsuario, contraseña, sql;
        nombre = jTextFieldNombre.getText();
        apellido = jTextFieldApellido.getText();
        dni = jTextFieldDni.getText();
        localidad = jTextFieldLocalidad.getText();
        direccion = jTextFieldDireccion.getText();
        fechaNacimiento = jComboBoxAnios.getSelectedItem().toString() + "-"
                + jComboBoxMeses.getSelectedItem().toString() + "-"
                + jComboBoxDias.getSelectedItem().toString();
        email = jTextFieldMail.getText();
        nombreUsuario = jTextFieldNickName.getText();
        contraseña = new String(jPasswordFieldContrasenia.getPassword());

        sql = ("INSERT INTO cliente(nombre,apellido,dni,localidad,direccion,fecha_nacimiento,mail)"
                + "VALUES(?,?,?,?,?,?,?)");
        PreparedStatement pst = cn.prepareStatement(sql);
        pst.setString(1, nombre);
        pst.setString(2, apellido);
        pst.setString(3, dni);
        pst.setString(4, localidad);
        pst.setString(5, direccion);
        pst.setString(6, fechaNacimiento);
        pst.setString(7, email);
        pst.execute();
        pst.close();

        //BUSCO EL ULTIMO REGISTRO DE LA TABLA CLIENTE PARA GUARDAR EL ID
        String idUltimoCliente = "";
        String SQLIdCliente = ("SELECT * FROM  cliente ORDER BY idcliente DESC");

        Statement st2 = cn.createStatement(); //CREO EL OBJETO STATEMENT
        ResultSet rs2 = st2.executeQuery(SQLIdCliente); //EJECUTO LA CONSULTA SQL
        if (rs2.next()) {

            idUltimoCliente = rs2.getString("idCliente");
        }

        //INGRESO EL USUARIO Y CONTRASEÑA EN LA TABLA USUARIO
        int id_cliente = Integer.parseInt(idUltimoCliente);
        String SQLCuenta = 
                ("INSERT INTO usuario (nickname,contrasenia,idcliente)VALUES(?,?,?)");
        PreparedStatement PUser = cn.prepareStatement(SQLCuenta);
        PUser.setString(1, nombreUsuario);
        PUser.setString(2, contraseña);
        PUser.setInt(3, id_cliente);
        PUser.execute();
        PUser.close();

        JOptionPane.showMessageDialog(null, "Datos registrados");
        this.dispose();
        Login vps = new Login();
        vps.setVisible(true);

    }

    public boolean comprobarDatosTarjeta() {   //Comprueba los datos de LA TARJETA
        if (jRadioButtonTarjeta.isSelected() == true) {

            if (jTextFieldTitularTarjeta.getText().length() < 8
                    || jTextFieldNumeroTarjeta.getText().length() < 16
                    || jTextFieldVencimientoTarjetaMes.getText().length() < 2
                    || jTextFieldVencimientoTarjetaAnio.getText().length() < 4
                    || jTextFieldCodigoTarjeta.getText().length() < 3) {
                JOptionPane.showMessageDialog(null, "Datos de la tarjeta incompletos",
                        "Datos incompletos", JOptionPane.ERROR_MESSAGE);
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }
    }

    public void soloNumeros(java.awt.event.KeyEvent evt) {  //RESTRINGE SOLO NUMEROS
        char c = evt.getKeyChar();
        if (c < '0' || c > '9') {
            evt.consume();
        }
    }

    public void soloLetras(KeyEvent evt) {   //RESTRINGE SOLO LETRAS
        Character c = evt.getKeyChar();
        if (!Character.isLetter(c) && c != KeyEvent.VK_SPACE) {
            evt.consume();
        }

    }

    public void ComprobarSeleccion() {//METODO PARA CUANDO CAMBIA LA SELECCION DE TARJETA
        if (jRadioButtonTarjeta.isSelected() == true) {
            for (int i = 0; i < jPanel1.getComponents().length; i++) {
                jPanel1.getComponent(i).setEnabled(true);
            }
        } else {
            for (int i = 0; i < jPanel1.getComponents().length; i++) {
                jPanel1.getComponent(i).setEnabled(false);
            }
        }
    }

    private void getanios() {//METODO PARA LLENAR EL COMBOBOX DE AÑOS
        List<Integer> anios = new ArrayList<>();
        for (int i = 2018; i >= 1920; i--) {
            anios.add(i);
        }
        jComboBoxAnios.setModel(new DefaultComboBoxModel(anios.toArray(new Integer[anios.size()])));
    }

    public boolean verificaciones() {//VERIFICO TODOS LOS TEXTFIELDS PARA QUE NO SEAN MENORES A 3 CARACTERES
        if (jTextFieldNombre.getText().length() < 3 || jTextFieldApellido.getText().length() < 3
                || jTextFieldDni.getText().length() < 8 || jTextFieldLocalidad.getText().length() < 3
                || jTextFieldDireccion.getText().length() < 3 || jTextFieldNickName.getText().length() < 3
                || jTextFieldMail.getText().length() < 3) {
            JOptionPane.showMessageDialog(null, "Uno o mas campos invalidos",
                    "Revisar datos ingresados", JOptionPane.ERROR_MESSAGE);
        } else {
            if (jPasswordFieldContrasenia.getText().length() < 3) {
                JOptionPane.showMessageDialog(null, "Ingrese otra contraseña",
                        "Contraseña demasiado corta", JOptionPane.ERROR_MESSAGE);
            } else {
                return true;
            }
        }
        return false;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabelIcono1 = new javax.swing.JLabel();
        jLabelRegistrarse = new javax.swing.JLabel();
        jLabelNombre = new javax.swing.JLabel();
        jLabelApellido = new javax.swing.JLabel();
        jLabelDni = new javax.swing.JLabel();
        jLabelLocalidad = new javax.swing.JLabel();
        jLabelDireccion = new javax.swing.JLabel();
        jLabelFechaNaci = new javax.swing.JLabel();
        jLabelMail = new javax.swing.JLabel();
        jLabelNickname = new javax.swing.JLabel();
        jLabelContrasenia = new javax.swing.JLabel();
        jTextFieldNombre = new javax.swing.JTextField();
        jTextFieldApellido = new javax.swing.JTextField();
        jTextFieldDni = new javax.swing.JTextField();
        jTextFieldLocalidad = new javax.swing.JTextField();
        jTextFieldDireccion = new javax.swing.JTextField();
        jTextFieldMail = new javax.swing.JTextField();
        jTextFieldNickName = new javax.swing.JTextField();
        jPasswordFieldContrasenia = new javax.swing.JPasswordField();
        jButtonCrearUsuario = new javax.swing.JButton();
        jRadioButtonTarjeta = new javax.swing.JRadioButton();
        jPanel1 = new javax.swing.JPanel();
        jLabelNombreTitular = new javax.swing.JLabel();
        jLabelVencimiento = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTextFieldTitularTarjeta = new javax.swing.JTextField();
        jTextFieldNumeroTarjeta = new javax.swing.JTextField();
        jTextFieldVencimientoTarjetaMes = new javax.swing.JTextField();
        jTextFieldCodigoTarjeta = new javax.swing.JTextField();
        jLabelIconoTarjeta = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jTextFieldVencimientoTarjetaAnio = new javax.swing.JTextField();
        jButtonVolver = new javax.swing.JButton();
        jLabelNombreOk = new javax.swing.JLabel();
        jLabelApellidoOk = new javax.swing.JLabel();
        jLabelDniOk = new javax.swing.JLabel();
        jLabelLocalidadOk = new javax.swing.JLabel();
        jLabelDireccionOk = new javax.swing.JLabel();
        jLabelMailOk = new javax.swing.JLabel();
        jLabelUserOk = new javax.swing.JLabel();
        jLabelNombreError = new javax.swing.JLabel();
        jLabelContraOk = new javax.swing.JLabel();
        jLabelApellidoError = new javax.swing.JLabel();
        jLabelDniError = new javax.swing.JLabel();
        jLabelLocalidadError = new javax.swing.JLabel();
        jLabelDireccionError = new javax.swing.JLabel();
        jLabelMailError = new javax.swing.JLabel();
        jLabelUserError = new javax.swing.JLabel();
        jLabelContraError = new javax.swing.JLabel();
        jComboBoxDias = new javax.swing.JComboBox<>();
        jComboBoxMeses = new javax.swing.JComboBox<>();
        jComboBoxAnios = new javax.swing.JComboBox<>();
        jLabelMmYyyy = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabelIcono1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Internet_World_274 (1).png"))); // NOI18N
        getContentPane().add(jLabelIcono1, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 0, 150, 160));

        jLabelRegistrarse.setBackground(new java.awt.Color(0, 0, 255));
        jLabelRegistrarse.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 3, 48)); // NOI18N
        jLabelRegistrarse.setForeground(new java.awt.Color(0, 204, 204));
        jLabelRegistrarse.setText("Registrarse");
        getContentPane().add(jLabelRegistrarse, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 0, 280, 70));

        jLabelNombre.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabelNombre.setForeground(new java.awt.Color(255, 255, 255));
        jLabelNombre.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabelNombre.setText("Nombre : ");
        getContentPane().add(jLabelNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, 90, 30));

        jLabelApellido.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabelApellido.setForeground(new java.awt.Color(255, 255, 255));
        jLabelApellido.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabelApellido.setText("Apellido : ");
        jLabelApellido.setPreferredSize(new java.awt.Dimension(84, 22));
        getContentPane().add(jLabelApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 140, 90, 30));

        jLabelDni.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabelDni.setForeground(new java.awt.Color(255, 255, 255));
        jLabelDni.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabelDni.setText("   DNI : ");
        jLabelDni.setPreferredSize(new java.awt.Dimension(84, 22));
        getContentPane().add(jLabelDni, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 180, 70, 30));

        jLabelLocalidad.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabelLocalidad.setForeground(new java.awt.Color(255, 255, 255));
        jLabelLocalidad.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabelLocalidad.setText(" Localidad : ");
        jLabelLocalidad.setPreferredSize(new java.awt.Dimension(84, 22));
        getContentPane().add(jLabelLocalidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 220, 110, 30));

        jLabelDireccion.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabelDireccion.setForeground(new java.awt.Color(255, 255, 255));
        jLabelDireccion.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabelDireccion.setText(" Direccion : ");
        getContentPane().add(jLabelDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 260, 110, 30));

        jLabelFechaNaci.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabelFechaNaci.setForeground(new java.awt.Color(255, 255, 255));
        jLabelFechaNaci.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabelFechaNaci.setText("  Fecha nacimiento : ");
        getContentPane().add(jLabelFechaNaci, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, 190, 30));

        jLabelMail.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabelMail.setForeground(new java.awt.Color(255, 255, 255));
        jLabelMail.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabelMail.setText("E-mail  : ");
        getContentPane().add(jLabelMail, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 340, 80, 30));

        jLabelNickname.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabelNickname.setForeground(new java.awt.Color(255, 255, 255));
        jLabelNickname.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabelNickname.setText("  Nombre usuario : ");
        getContentPane().add(jLabelNickname, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 180, 30));

        jLabelContrasenia.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabelContrasenia.setForeground(new java.awt.Color(255, 255, 255));
        jLabelContrasenia.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabelContrasenia.setText("Contraseña : ");
        getContentPane().add(jLabelContrasenia, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 420, 140, 30));

        jTextFieldNombre.setBackground(new java.awt.Color(0, 51, 51));
        jTextFieldNombre.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTextFieldNombre.setForeground(new java.awt.Color(255, 255, 255));
        jTextFieldNombre.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextFieldNombreFocusLost(evt);
            }
        });
        jTextFieldNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldNombreKeyTyped(evt);
            }
        });
        getContentPane().add(jTextFieldNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 100, 170, 30));

        jTextFieldApellido.setBackground(new java.awt.Color(0, 51, 51));
        jTextFieldApellido.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTextFieldApellido.setForeground(new java.awt.Color(255, 255, 255));
        jTextFieldApellido.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextFieldApellidoFocusLost(evt);
            }
        });
        jTextFieldApellido.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldApellidoKeyTyped(evt);
            }
        });
        getContentPane().add(jTextFieldApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 140, 170, 30));

        jTextFieldDni.setBackground(new java.awt.Color(0, 51, 51));
        jTextFieldDni.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTextFieldDni.setForeground(new java.awt.Color(255, 255, 255));
        jTextFieldDni.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextFieldDniFocusLost(evt);
            }
        });
        jTextFieldDni.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldDniKeyTyped(evt);
            }
        });
        getContentPane().add(jTextFieldDni, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 180, 170, 30));

        jTextFieldLocalidad.setBackground(new java.awt.Color(0, 51, 51));
        jTextFieldLocalidad.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTextFieldLocalidad.setForeground(new java.awt.Color(255, 255, 255));
        jTextFieldLocalidad.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextFieldLocalidadFocusLost(evt);
            }
        });
        jTextFieldLocalidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldLocalidadKeyTyped(evt);
            }
        });
        getContentPane().add(jTextFieldLocalidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 220, 170, 30));

        jTextFieldDireccion.setBackground(new java.awt.Color(0, 51, 51));
        jTextFieldDireccion.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTextFieldDireccion.setForeground(new java.awt.Color(255, 255, 255));
        jTextFieldDireccion.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextFieldDireccionFocusLost(evt);
            }
        });
        getContentPane().add(jTextFieldDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 260, 170, 30));

        jTextFieldMail.setBackground(new java.awt.Color(0, 51, 51));
        jTextFieldMail.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTextFieldMail.setForeground(new java.awt.Color(255, 255, 255));
        jTextFieldMail.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextFieldMailFocusLost(evt);
            }
        });
        getContentPane().add(jTextFieldMail, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 340, 170, 30));

        jTextFieldNickName.setBackground(new java.awt.Color(0, 51, 51));
        jTextFieldNickName.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTextFieldNickName.setForeground(new java.awt.Color(255, 255, 255));
        jTextFieldNickName.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextFieldNickNameFocusLost(evt);
            }
        });
        getContentPane().add(jTextFieldNickName, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 380, 170, 30));

        jPasswordFieldContrasenia.setBackground(new java.awt.Color(0, 51, 51));
        jPasswordFieldContrasenia.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jPasswordFieldContrasenia.setForeground(new java.awt.Color(255, 255, 255));
        jPasswordFieldContrasenia.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jPasswordFieldContraseniaFocusLost(evt);
            }
        });
        getContentPane().add(jPasswordFieldContrasenia, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 420, 170, 30));

        jButtonCrearUsuario.setBackground(new java.awt.Color(0, 51, 102));
        jButtonCrearUsuario.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButtonCrearUsuario.setForeground(new java.awt.Color(255, 255, 255));
        jButtonCrearUsuario.setText("Crear usuario");
        jButtonCrearUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCrearUsuarioActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonCrearUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 480, -1, 30));

        jRadioButtonTarjeta.setBackground(new java.awt.Color(0, 51, 51));
        jRadioButtonTarjeta.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jRadioButtonTarjeta.setForeground(new java.awt.Color(255, 255, 255));
        jRadioButtonTarjeta.setText("¿Agregar tarjeta de credito?");
        jRadioButtonTarjeta.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jRadioButtonTarjeta.setOpaque(false);
        jRadioButtonTarjeta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonTarjetaActionPerformed(evt);
            }
        });
        getContentPane().add(jRadioButtonTarjeta, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 160, 230, 40));

        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.setForeground(new java.awt.Color(0, 51, 51));
        jPanel1.setOpaque(false);

        jLabelNombreTitular.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabelNombreTitular.setForeground(new java.awt.Color(255, 255, 255));
        jLabelNombreTitular.setText("Numero :");

        jLabelVencimiento.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabelVencimiento.setForeground(new java.awt.Color(255, 255, 255));
        jLabelVencimiento.setText("Vencimiento :");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Nombre titular :");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Cod. seguridad:");

        jTextFieldTitularTarjeta.setBackground(new java.awt.Color(0, 51, 51));
        jTextFieldTitularTarjeta.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTextFieldTitularTarjeta.setForeground(new java.awt.Color(255, 255, 255));
        jTextFieldTitularTarjeta.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldTitularTarjetaKeyTyped(evt);
            }
        });

        jTextFieldNumeroTarjeta.setBackground(new java.awt.Color(0, 51, 51));
        jTextFieldNumeroTarjeta.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTextFieldNumeroTarjeta.setForeground(new java.awt.Color(255, 255, 255));
        jTextFieldNumeroTarjeta.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldNumeroTarjetaKeyTyped(evt);
            }
        });

        jTextFieldVencimientoTarjetaMes.setBackground(new java.awt.Color(0, 51, 51));
        jTextFieldVencimientoTarjetaMes.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTextFieldVencimientoTarjetaMes.setForeground(new java.awt.Color(255, 255, 255));
        jTextFieldVencimientoTarjetaMes.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldVencimientoTarjetaMesKeyTyped(evt);
            }
        });

        jTextFieldCodigoTarjeta.setBackground(new java.awt.Color(0, 51, 51));
        jTextFieldCodigoTarjeta.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTextFieldCodigoTarjeta.setForeground(new java.awt.Color(255, 255, 255));
        jTextFieldCodigoTarjeta.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldCodigoTarjetaKeyTyped(evt);
            }
        });

        jLabelIconoTarjeta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/credit_card_21458.png"))); // NOI18N

        jLabel1.setFont(new java.awt.Font("Century Gothic", 2, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("MES   /  AÑO");

        jTextFieldVencimientoTarjetaAnio.setBackground(new java.awt.Color(0, 51, 51));
        jTextFieldVencimientoTarjetaAnio.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTextFieldVencimientoTarjetaAnio.setForeground(new java.awt.Color(255, 255, 255));
        jTextFieldVencimientoTarjetaAnio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldVencimientoTarjetaAnioKeyTyped(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabelVencimiento)
                    .addComponent(jLabelNombreTitular, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextFieldNumeroTarjeta)
                            .addComponent(jTextFieldTitularTarjeta))
                        .addContainerGap())
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextFieldCodigoTarjeta, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jTextFieldVencimientoTarjetaMes, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextFieldVencimientoTarjetaAnio, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 4, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelIconoTarjeta, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextFieldTitularTarjeta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelNombreTitular, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextFieldNumeroTarjeta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(4, 4, 4)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelVencimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextFieldVencimientoTarjetaMes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextFieldVencimientoTarjetaAnio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jTextFieldCodigoTarjeta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(52, 52, 52))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabelIconoTarjeta, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 220, 400, 260));

        jButtonVolver.setBackground(new java.awt.Color(0, 51, 102));
        jButtonVolver.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButtonVolver.setForeground(new java.awt.Color(255, 255, 255));
        jButtonVolver.setText("Volver a inicio");
        jButtonVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonVolverActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonVolver, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 480, -1, 30));

        jLabelNombreOk.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/ic_check_128_28312.png"))); // NOI18N
        getContentPane().add(jLabelNombreOk, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 100, -1, 30));

        jLabelApellidoOk.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/ic_check_128_28312.png"))); // NOI18N
        getContentPane().add(jLabelApellidoOk, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 140, -1, 30));

        jLabelDniOk.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/ic_check_128_28312.png"))); // NOI18N
        getContentPane().add(jLabelDniOk, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 180, -1, 30));

        jLabelLocalidadOk.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/ic_check_128_28312.png"))); // NOI18N
        getContentPane().add(jLabelLocalidadOk, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 220, -1, 30));

        jLabelDireccionOk.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/ic_check_128_28312.png"))); // NOI18N
        getContentPane().add(jLabelDireccionOk, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 260, -1, 30));

        jLabelMailOk.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/ic_check_128_28312.png"))); // NOI18N
        getContentPane().add(jLabelMailOk, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 340, -1, 30));

        jLabelUserOk.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/ic_check_128_28312.png"))); // NOI18N
        getContentPane().add(jLabelUserOk, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 380, -1, 30));

        jLabelNombreError.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabelNombreError.setForeground(new java.awt.Color(255, 255, 255));
        jLabelNombreError.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/sign-error-icon_34362.png"))); // NOI18N
        getContentPane().add(jLabelNombreError, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 100, 30, -1));

        jLabelContraOk.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/ic_check_128_28312.png"))); // NOI18N
        getContentPane().add(jLabelContraOk, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 420, -1, 30));

        jLabelApellidoError.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/sign-error-icon_34362.png"))); // NOI18N
        getContentPane().add(jLabelApellidoError, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 140, -1, 30));

        jLabelDniError.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/sign-error-icon_34362.png"))); // NOI18N
        getContentPane().add(jLabelDniError, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 180, -1, 30));

        jLabelLocalidadError.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/sign-error-icon_34362.png"))); // NOI18N
        getContentPane().add(jLabelLocalidadError, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 220, -1, 30));

        jLabelDireccionError.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/sign-error-icon_34362.png"))); // NOI18N
        getContentPane().add(jLabelDireccionError, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 260, -1, 30));

        jLabelMailError.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/sign-error-icon_34362.png"))); // NOI18N
        getContentPane().add(jLabelMailError, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 340, -1, 30));

        jLabelUserError.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/sign-error-icon_34362.png"))); // NOI18N
        getContentPane().add(jLabelUserError, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 380, -1, 30));

        jLabelContraError.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/sign-error-icon_34362.png"))); // NOI18N
        getContentPane().add(jLabelContraError, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 420, -1, 30));

        jComboBoxDias.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        getContentPane().add(jComboBoxDias, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 300, 50, 30));

        jComboBoxMeses.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        getContentPane().add(jComboBoxMeses, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 300, 60, 30));
        getContentPane().add(jComboBoxAnios, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 300, 60, 30));

        jLabelMmYyyy.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabelMmYyyy.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/FondoAzul.png"))); // NOI18N
        jLabelMmYyyy.setPreferredSize(new java.awt.Dimension(510, 320));
        getContentPane().add(jLabelMmYyyy, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 520));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonCrearUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCrearUsuarioActionPerformed
        if (verificaciones() == true) {
            if (jRadioButtonTarjeta.isSelected() == true && comprobarDatosTarjeta() == true) {
                IngresarUsuarioYTarjeta();
            }
            if (jRadioButtonTarjeta.isSelected() == false && verificaciones() == true) {
                try {
                    IngresarUsuarioSinTarjeta();
                } catch (SQLException ex) {
                    Logger.getLogger(NuevoUsuario.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

    }//GEN-LAST:event_jButtonCrearUsuarioActionPerformed

    private void jRadioButtonTarjetaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonTarjetaActionPerformed
        //SI SE SELECCIONA SE ACTIVA EL PANEL, SINO SE VUELVE A DESACTIVAR
        ComprobarSeleccion();
    }//GEN-LAST:event_jRadioButtonTarjetaActionPerformed

    private void jButtonVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonVolverActionPerformed
        // TODO add your handling code here:
        this.dispose();
        Login vps = new Login();
        vps.setVisible(true);

    }//GEN-LAST:event_jButtonVolverActionPerformed

    private void jTextFieldNombreFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextFieldNombreFocusLost
        // TODO add your handling code here:
        if (jTextFieldNombre.getText().length() < 3) {
            jLabelNombreError.setVisible(true);
            jLabelNombreOk.setVisible(false);
        } else {
            jLabelNombreOk.setVisible(true);
            jLabelNombreError.setVisible(false);
        }

    }//GEN-LAST:event_jTextFieldNombreFocusLost

    private void jTextFieldApellidoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextFieldApellidoFocusLost
        // TODO add your handling code here:
        if (jTextFieldApellido.getText().length() < 3) {
            jLabelApellidoError.setVisible(true);
            jLabelApellidoOk.setVisible(false);
        } else {
            jLabelApellidoOk.setVisible(true);
            jLabelApellidoError.setVisible(false);
        }
    }//GEN-LAST:event_jTextFieldApellidoFocusLost

    private void jTextFieldDniFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextFieldDniFocusLost
        // TODO add your handling code here:
        if (jTextFieldDni.getText().length() < 8) {
            jLabelDniError.setVisible(true);
            jLabelDniOk.setVisible(false);
        } else {
            jLabelDniOk.setVisible(true);
            jLabelDniError.setVisible(false);
        }
    }//GEN-LAST:event_jTextFieldDniFocusLost

    private void jTextFieldLocalidadFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextFieldLocalidadFocusLost
        // TODO add your handling code here:
        if (jTextFieldLocalidad.getText().length() < 3) {
            jLabelLocalidadError.setVisible(true);
            jLabelLocalidadOk.setVisible(false);
        } else {
            jLabelLocalidadOk.setVisible(true);
            jLabelLocalidadError.setVisible(false);
        }
    }//GEN-LAST:event_jTextFieldLocalidadFocusLost

    private void jTextFieldDireccionFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextFieldDireccionFocusLost
        // TODO add your handling code here:
        if (jTextFieldDireccion.getText().length() < 3) {
            jLabelDireccionError.setVisible(true);
            jLabelDireccionOk.setVisible(false);
        } else {
            jLabelDireccionOk.setVisible(true);
            jLabelDireccionError.setVisible(false);
        }
    }//GEN-LAST:event_jTextFieldDireccionFocusLost

    private void jTextFieldMailFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextFieldMailFocusLost
        // TODO add your handling code here:
        if (jTextFieldMail.getText().length() < 3) {
            jLabelMailError.setVisible(true);
            jLabelMailOk.setVisible(false);
        } else {
            jLabelMailOk.setVisible(true);
            jLabelMailError.setVisible(false);
        }
    }//GEN-LAST:event_jTextFieldMailFocusLost

    private void jTextFieldNickNameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextFieldNickNameFocusLost
        // TODO add your handling code here:
        if (jTextFieldNickName.getText().length() < 3) {
            jLabelUserError.setVisible(true);
            jLabelUserOk.setVisible(false);
        } else {
            jLabelUserOk.setVisible(true);
            jLabelUserError.setVisible(false);
        }
    }//GEN-LAST:event_jTextFieldNickNameFocusLost

    private void jPasswordFieldContraseniaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jPasswordFieldContraseniaFocusLost
        // TODO add your handling code here:
        if (jPasswordFieldContrasenia.getText().length() < 3) {
            jLabelContraError.setVisible(true);
            jLabelContraOk.setVisible(false);
        } else {
            jLabelContraOk.setVisible(true);
            jLabelContraError.setVisible(false);
        }
    }//GEN-LAST:event_jPasswordFieldContraseniaFocusLost

    private void jTextFieldNumeroTarjetaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldNumeroTarjetaKeyTyped
        // TODO add your handling code here:
        soloNumeros(evt);
        if (jTextFieldNumeroTarjeta.getText().length() == 16) {//RESTRINJO LA CANTIDAD DE CARACTERES
            evt.consume();
        }
    }//GEN-LAST:event_jTextFieldNumeroTarjetaKeyTyped

    private void jTextFieldCodigoTarjetaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldCodigoTarjetaKeyTyped
        // TODO add your handling code here:
        soloNumeros(evt);
        if (jTextFieldCodigoTarjeta.getText().length() == 3) {//RESTRINJO LA CANTIDAD DE CARACTERES
            evt.consume();
        }
    }//GEN-LAST:event_jTextFieldCodigoTarjetaKeyTyped

    private void jTextFieldVencimientoTarjetaMesKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldVencimientoTarjetaMesKeyTyped
        // TODO add your handling code here:
        soloNumeros(evt);
        if (jTextFieldVencimientoTarjetaMes.getText().length() == 2) {//RESTRINJO LA CANTIDAD DE CARACTERES
            evt.consume();
        }
    }//GEN-LAST:event_jTextFieldVencimientoTarjetaMesKeyTyped

    private void jTextFieldDniKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldDniKeyTyped
        // TODO add your handling code here:
        soloNumeros(evt);
        if (jTextFieldDni.getText().length() == 8) {
            evt.consume();
        }
    }//GEN-LAST:event_jTextFieldDniKeyTyped

    private void jTextFieldApellidoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldApellidoKeyTyped
        soloLetras(evt);
    }//GEN-LAST:event_jTextFieldApellidoKeyTyped

    private void jTextFieldLocalidadKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldLocalidadKeyTyped
        // TODO add your handling code here:
        soloLetras(evt);
    }//GEN-LAST:event_jTextFieldLocalidadKeyTyped

    private void jTextFieldTitularTarjetaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldTitularTarjetaKeyTyped
        // TODO add your handling code here:
        soloLetras(evt);
    }//GEN-LAST:event_jTextFieldTitularTarjetaKeyTyped

    private void jTextFieldNombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldNombreKeyTyped
        // TODO add your handling code here:
        soloLetras(evt);
    }//GEN-LAST:event_jTextFieldNombreKeyTyped

    private void jTextFieldVencimientoTarjetaAnioKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldVencimientoTarjetaAnioKeyTyped
        // TODO add your handling code here:
        soloNumeros(evt);
        if (jTextFieldVencimientoTarjetaAnio.getText().length() == 4) {
            evt.consume();
        }
    }//GEN-LAST:event_jTextFieldVencimientoTarjetaAnioKeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NuevoUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NuevoUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NuevoUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NuevoUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NuevoUsuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCrearUsuario;
    private javax.swing.JButton jButtonVolver;
    private javax.swing.JComboBox<String> jComboBoxAnios;
    private javax.swing.JComboBox<String> jComboBoxDias;
    private javax.swing.JComboBox<String> jComboBoxMeses;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabelApellido;
    private javax.swing.JLabel jLabelApellidoError;
    private javax.swing.JLabel jLabelApellidoOk;
    private javax.swing.JLabel jLabelContraError;
    private javax.swing.JLabel jLabelContraOk;
    private javax.swing.JLabel jLabelContrasenia;
    private javax.swing.JLabel jLabelDireccion;
    private javax.swing.JLabel jLabelDireccionError;
    private javax.swing.JLabel jLabelDireccionOk;
    private javax.swing.JLabel jLabelDni;
    private javax.swing.JLabel jLabelDniError;
    private javax.swing.JLabel jLabelDniOk;
    private javax.swing.JLabel jLabelFechaNaci;
    private javax.swing.JLabel jLabelIcono1;
    private javax.swing.JLabel jLabelIconoTarjeta;
    private javax.swing.JLabel jLabelLocalidad;
    private javax.swing.JLabel jLabelLocalidadError;
    private javax.swing.JLabel jLabelLocalidadOk;
    private javax.swing.JLabel jLabelMail;
    private javax.swing.JLabel jLabelMailError;
    private javax.swing.JLabel jLabelMailOk;
    private javax.swing.JLabel jLabelMmYyyy;
    private javax.swing.JLabel jLabelNickname;
    private javax.swing.JLabel jLabelNombre;
    private javax.swing.JLabel jLabelNombreError;
    private javax.swing.JLabel jLabelNombreOk;
    private javax.swing.JLabel jLabelNombreTitular;
    private javax.swing.JLabel jLabelRegistrarse;
    private javax.swing.JLabel jLabelUserError;
    private javax.swing.JLabel jLabelUserOk;
    private javax.swing.JLabel jLabelVencimiento;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPasswordFieldContrasenia;
    private javax.swing.JRadioButton jRadioButtonTarjeta;
    private javax.swing.JTextField jTextFieldApellido;
    private javax.swing.JTextField jTextFieldCodigoTarjeta;
    private javax.swing.JTextField jTextFieldDireccion;
    private javax.swing.JTextField jTextFieldDni;
    private javax.swing.JTextField jTextFieldLocalidad;
    private javax.swing.JTextField jTextFieldMail;
    private javax.swing.JTextField jTextFieldNickName;
    private javax.swing.JTextField jTextFieldNombre;
    private javax.swing.JTextField jTextFieldNumeroTarjeta;
    private javax.swing.JTextField jTextFieldTitularTarjeta;
    private javax.swing.JTextField jTextFieldVencimientoTarjetaAnio;
    private javax.swing.JTextField jTextFieldVencimientoTarjetaMes;
    // End of variables declaration//GEN-END:variables

    BaseDeDatos mysql = new BaseDeDatos();
    Connection cn = mysql.Connectar();
}
