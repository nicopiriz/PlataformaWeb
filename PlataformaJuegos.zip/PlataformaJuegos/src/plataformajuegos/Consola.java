package plataformajuegos;

public class Consola {
    private int idConsola;
    private String nombre;
    
    //Constructor
    public Consola(){
    }
    //Getters and Setters
    public int getIdConsola() {
        return idConsola;
    }
    public void setIdConsola(int idConsola) {
        this.idConsola = idConsola;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}