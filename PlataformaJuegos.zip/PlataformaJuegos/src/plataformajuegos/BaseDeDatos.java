
package plataformajuegos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class BaseDeDatos {
    public String db= "plataformajuegos";
    public String url ="jdbc:mysql://localhost/"+db;
    public String user = "root";
    public String pass= "1234";
    
    public static String user2="root";
    public static String pass2="1234";
    public static String db2="plataformajuegos";
    public static String url2 ="jdbc:mysql://localhost/"+db2;
    
    public BaseDeDatos(){
    }
    
    public Connection Connectar (){
        Connection link = null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            link= DriverManager.getConnection(url,user,pass);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        return link;
    }
    
        public static Connection getConexion (){
        Connection cn=null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            cn= DriverManager.getConnection(url2,user2,pass2);
        }
        catch(Exception e){
            System.out.println(String.valueOf(e));
        }
        return cn;
    }
    
    public static ResultSet getTabla(String Consulta){
        Connection cn = getConexion();
        Statement st;
        ResultSet datos=null;
        try{
            st=cn.createStatement();
            datos=st.executeQuery(Consulta);
        }
        catch(Exception e){
            System.out.print(e.toString());
        }
        return datos;
    }
    
            
            
            
}

