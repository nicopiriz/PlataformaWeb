
package plataformajuegos;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class BaseDeDatos {
    public String db= "plataformajuegos";
    public String url ="jdbc:mysql://localhost/"+db;
    public String user = "root";
    public String pass= "1234";
    
    public BaseDeDatos(){
    }
    
    public Connection Connectar (){
        Connection link = null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            link= DriverManager.getConnection(url,user,pass);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        return link;
    }
    
            
            
            
}

