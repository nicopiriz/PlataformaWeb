package plataformajuegos;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConexionSQL {

    Connection co;
    Statement stm;

    public ConexionSQL() {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection co= DriverManager.getConnection("jdbc:mysql://localhost:3306/plataformajuegos", "root","1234");
            Statement stm= co.createStatement();
            ResultSet rs= stm.executeQuery("SELECT * from cliente");
            
            while(rs.next()){
                System.out.println(rs.getString("nombre"));
                System.out.println(rs.getString(3));
            }
            
        }
        catch(ClassNotFoundException exc){
            exc.printStackTrace();
        }
        catch(SQLException ex){
            Logger.getLogger(ConexionSQL.class.getName()).log(Level.SEVERE,null, ex);
        }
    }   

}
