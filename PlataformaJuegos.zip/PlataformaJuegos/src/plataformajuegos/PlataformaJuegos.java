package plataformajuegos;

import vista.*;
public class PlataformaJuegos {

    public static void main(String[] args) {
     //   ConexionSQL con = new ConexionSQL();
       Login vista = new Login();
       vista.setVisible(true);
    }
}