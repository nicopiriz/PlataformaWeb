package plataformajuegos;

public class PlataformaJuegos {

    public static void main(String[] args) {
        ConexionSQL con = new ConexionSQL();
    }
}